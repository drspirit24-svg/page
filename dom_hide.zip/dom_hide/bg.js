function getUrlParams() 
{
    var params = {};
	window.location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(str, key, value) { params[key] = value; });
   
	return params;
}

function ad_clear()
{
	$('.erd-ads-area').remove();
	$('.erd-container').removeClass('erdWrap');

	$('#aswift_1').remove();
	$('#aswift_2').remove();

	$('#vi-smartbanner').remove();

	$('.adsbygoogle').remove();

	$('div[class^="google-anno"]').remove();
	$('div[id^="google-anno"]').remove();
}

$(document).on("click", function() {
	ad_clear();
});

$(function () {
	$('.w_banner').remove();
	$('.basic-banner').remove();
	$('.board-tail-banner').remove();
	$('.ban_shuffle').remove();

	$('#gnb_pc > div > div > ul').children('li:eq(8)').remove();
	$('#gnb_pc > div > div > ul').children('li:eq(7)').remove();
	$('#gnb_pc > div > div > ul').children('li:eq(6)').remove();
	$('#gnb_pc > div > div > ul').children('li:eq(5)').remove();
	$('#gnb_pc > div > div > ul').children('li:eq(4)').remove();
	$('#gnb_pc > div > div > ul').children('li:eq(0)').remove();

	$('.banner_item').remove();

	$('#main-banner-view').remove();
	$('#id_mbv').remove();

	$('.at-title').remove();

	$("div[id^='exo']").each(function() {
		$(this).remove();
	});
	$('.announ').remove();
	$('.insty').remove();
	$('#exoall').remove();

	$('.video-long-banner').remove();
	$('.partner-banner-flex').remove();	

	$('#hd_pop').remove();
	$('div[id^="widget_"]').remove();
	$('div[class^="row hilights-con"]').remove();
	$('#myUniqueId').remove();

	//$('div[class^="hidden-sm hidden-xs"]:nth-child(2)').remove();

	$('.event8').remove();

	var tm_cls = $('#container').find('div:eq(0)').attr('class');	
	if(tm_cls && tm_cls.substring(0,15) == 'partner-br-wrap')
	{
		$('#container').find('div:eq(0)').remove();
	}

	$('.view-content > div').each(function(){
		tm_cls = $(this).attr('class');

		if(tm_cls && tm_cls.substring(0,15) == 'partner-br-wrap')
		{
			$(this).remove();
		}
	});

	$('.banner_wrap2').remove();
	$('.mobile-padding').remove();
	$('#bannerContainer').remove();
	$('.full.pc-only').parent().remove();

	$('#img_row_container').remove();
	$('.basic-post-gallery').remove();

	$('.main-intro').remove();
	$('.banner-area').remove();

	$('div[class^="ads"]').remove();

	setTimeout(ad_clear(),1000);

	var url_params = getUrlParams();
	console.log(url_params);
});
